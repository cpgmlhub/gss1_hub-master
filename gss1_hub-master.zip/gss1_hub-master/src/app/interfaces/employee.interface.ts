export interface Employee {
  firstName: string;
  lastName: string;
  years: number;
  profileImg: string;
}
